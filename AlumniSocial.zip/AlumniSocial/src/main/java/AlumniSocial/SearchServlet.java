package AlumniSocial;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

@WebServlet("/SearchServlet")
public class SearchServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String query = request.getParameter("query"); // Get search query from URL
        ArrayList<String> results = new ArrayList<>();

        if (query != null && !query.trim().isEmpty()) {
            try (Connection conn = DatabaseUtil.getConnection()) {
                String sql = "SELECT username FROM Users WHERE username LIKE ? OR bio LIKE ?";
                PreparedStatement stmt = conn.prepareStatement(sql);
                stmt.setString(1, "%" + query + "%");
                stmt.setString(2, "%" + query + "%");

                ResultSet rs = stmt.executeQuery();
                while (rs.next()) {
                    results.add(rs.getString("username")); // Add results to list
                }
            } catch (Exception e) {
                e.printStackTrace();
                request.setAttribute("error", "An error occurred during the search.");
            }
        }

        request.setAttribute("results", results);
        request.getRequestDispatcher("search.jsp").forward(request, response); // Forward to JSP
    }
}
