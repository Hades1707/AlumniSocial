package AlumniSocial;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SendConnectionRequestServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int alumniId = Integer.parseInt(request.getParameter("alumniId"));

        try (Connection conn = DatabaseUtil.getConnection()) {
            // Check if the users are already connected
            String checkConnectionSql = "SELECT COUNT(*) FROM connections WHERE (user_id = ? AND connected_user_id = ?) OR (user_id = ? AND connected_user_id = ?)";
            try (PreparedStatement checkStmt = conn.prepareStatement(checkConnectionSql)) {
                checkStmt.setInt(1, userId);
                checkStmt.setInt(2, alumniId);
                checkStmt.setInt(3, alumniId);
                checkStmt.setInt(4, userId);

                try (ResultSet rs = checkStmt.executeQuery()) {
                    if (rs.next() && rs.getInt(1) > 0) {
                        // Users are already connected
                        response.sendRedirect("connections.jsp?message=You%20are%20already%20connected%20with%20this%20user.");
                        return;
                    }
                }
            }

            // Insert the connection request (pending)
            String insertConnectionSql = "INSERT INTO connections (user_id, connected_user_id, date_connected) VALUES (?, ?, CURRENT_TIMESTAMP)";
            try (PreparedStatement stmt = conn.prepareStatement(insertConnectionSql)) {
                stmt.setInt(1, userId);
                stmt.setInt(2, alumniId);
                stmt.executeUpdate();
            }

            // Optional: Send a notification or store the connection request status as "pending"
            // This would involve creating a new table (e.g., `connection_requests`) to store pending requests.
            
            response.sendRedirect("connections.jsp?message=Connection%20request%20sent%20successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?message=An%20error%20occurred%20while%20sending%20the%20connection%20request.");
        }
    }
}
