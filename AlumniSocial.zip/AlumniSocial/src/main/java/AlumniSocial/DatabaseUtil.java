package AlumniSocial;

import java.io.File;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseUtil {

    // The JDBC URL for the SQLite database
    private static final String DATABASE_URL;

    static {
        DATABASE_URL = initializeDatabaseUrl();
    }

    /**
     * Initializes the database URL by locating the database file in the resources folder.
     *
     * @return The resolved SQLite JDBC URL.
     */
    private static String initializeDatabaseUrl() {
        try {
            // Load the SQLite JDBC driver
            Class.forName("org.sqlite.JDBC");

            // Locate the database file in the resources folder
            URL resource = DatabaseUtil.class.getClassLoader().getResource("alumnisocial.db");
            if (resource == null) {
                throw new IllegalStateException("Database file 'alumnisocial.db' not found in the resources folder.");
            }

            // Convert the resource URL to a File and validate existence
            File databaseFile = new File(resource.toURI());
            if (!databaseFile.exists()) {
                throw new IllegalStateException("Database file not found at: " + databaseFile.getAbsolutePath());
            }

            // Construct the SQLite JDBC URL
            return "jdbc:sqlite:" + databaseFile.getAbsolutePath();
        } catch (URISyntaxException e) {
            throw new IllegalStateException("Invalid URI for the database file.", e);
        } catch (ClassNotFoundException e) {
            throw new IllegalStateException("Failed to load SQLite JDBC driver.", e);
        } catch (Exception e) {
            throw new IllegalStateException("Unexpected error during database initialization.", e);
        }
    }

    /**
     * Establishes and returns a connection to the SQLite database.
     *
     * @return A Connection object for the SQLite database.
     * @throws SQLException If a database access error occurs.
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DATABASE_URL);
    }

    /**
     * Safely closes a database connection.
     *
     * @param connection The Connection object to close.
     */
    public static void closeConnection(Connection connection) {
        if (connection != null) {
            try {
                connection.close();
                System.out.println("Database connection closed successfully.");
            } catch (SQLException e) {
                System.err.println("Error closing database connection: " + e.getMessage());
            }
        }
    }
}
