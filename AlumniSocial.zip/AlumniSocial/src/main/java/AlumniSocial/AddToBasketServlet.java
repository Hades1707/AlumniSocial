package AlumniSocial;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

public class AddToBasketServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Get the product ID from the request parameter
        int productId = Integer.parseInt(request.getParameter("id"));
        
        // Get the user ID from the session
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        // Check if user is logged in, otherwise redirect to login page
        if (userId == null) {
            response.sendRedirect("login.jsp"); // Redirect to login if user is not authenticated
            return;
        }

        // Database operation to insert or update the basket
        try (Connection conn = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO basket (user_id, product_id, quantity) VALUES (?, ?, 1) "
                       + "ON CONFLICT(user_id, product_id) DO UPDATE SET quantity = quantity + 1";
            
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, userId);  // Set user ID parameter
                stmt.setInt(2, productId);  // Set product ID parameter
                stmt.executeUpdate();  // Execute the query to insert or update
            }
        } catch (Exception e) {
            e.printStackTrace(); // Log the exception, or you can use a logger instead of printing to console
            request.setAttribute("error", "An error occurred while adding the product to the basket.");
            request.getRequestDispatcher("errorPage.jsp").forward(request, response); // Show error page if exception occurs
            return;
        }

        // Redirect to the shop page after adding product to basket
        response.sendRedirect("shop.jsp");
    }
}
