package AlumniSocial;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdateUserServlet extends HttpServlet {
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");

        if (userId == null || role == null || !role.equals("admin")) {
            response.sendRedirect("login.jsp");
            return;
        }

        Integer targetUserId = Integer.parseInt(request.getParameter("targetUserId"));

        try (Connection conn = DatabaseUtil.getConnection()) {
            String sql = "SELECT username, privacy_setting, balance FROM users WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, targetUserId);
                try (ResultSet rs = stmt.executeQuery()) {
                    if (rs.next()) {
                        String username = rs.getString("username");
                        String privacySetting = rs.getString("privacy_setting");
                        double balance = rs.getDouble("balance");

                        request.setAttribute("username", username);
                        request.setAttribute("privacySetting", privacySetting);
                        request.setAttribute("balance", balance);
                        request.setAttribute("targetUserId", targetUserId);
                        request.getRequestDispatcher("updateUser.jsp").forward(request, response);
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?message=" + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");

        if (userId == null || role == null || !role.equals("admin")) {
            response.sendRedirect("login.jsp");
            return;
        }

        Integer targetUserId = Integer.parseInt(request.getParameter("targetUserId"));
        String newUsername = request.getParameter("username");
        String newPrivacySetting = request.getParameter("privacySetting");
        double newBalance = Double.parseDouble(request.getParameter("balance"));

        try (Connection conn = DatabaseUtil.getConnection()) {
            String sql = "UPDATE users SET username = ?, privacy_setting = ?, balance = ? WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, newUsername);
                stmt.setString(2, newPrivacySetting);
                stmt.setDouble(3, newBalance);
                stmt.setInt(4, targetUserId);
                int rowsUpdated = stmt.executeUpdate();

                if (rowsUpdated > 0) {
                    response.sendRedirect("admin.jsp");  // Redirect to admin dashboard after update
                } else {
                    response.sendRedirect("error.jsp?message=Update failed");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?message=" + e.getMessage());
        }
    }
}
