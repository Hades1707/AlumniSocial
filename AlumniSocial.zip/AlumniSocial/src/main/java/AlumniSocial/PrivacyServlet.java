package AlumniSocial;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;

@WebServlet("/PrivacyServlet")
public class PrivacyServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = (String) request.getSession().getAttribute("username");

        // Check if the user is logged in
        if (username == null || username.isEmpty()) {
            response.sendRedirect("login.jsp");
            return;
        }

        String privacySetting = request.getParameter("privacy_setting");

        // Validate the privacy setting
        if (privacySetting == null || privacySetting.trim().isEmpty()) {
            response.sendRedirect("privacy.jsp?error=Privacy setting cannot be empty");
            return;
        }

        // Database operation to update privacy settings
        try (Connection conn = DatabaseUtil.getConnection()) {
            String sql = "UPDATE users SET privacy_setting = ? WHERE username = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, privacySetting);
                stmt.setString(2, username);
                stmt.executeUpdate();
            }
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("privacy.jsp?error=Failed to update privacy settings: " + e.getMessage());
            return;
        }

        // Redirect with success message
        response.sendRedirect("privacy.jsp?success=Privacy settings updated");
    }
}
