package AlumniSocial;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.net.URLEncoder;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Fetch the user's balance
        double balance = 0.0;
        try (Connection conn = DatabaseUtil.getConnection()) {
            String balanceQuery = "SELECT balance FROM users WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(balanceQuery)) {
                stmt.setInt(1, userId);
                ResultSet rs = stmt.executeQuery();
                if (rs.next()) {
                    balance = rs.getDouble("balance");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            String encodedMessage = URLEncoder.encode("Error retrieving user balance: " + e.getMessage(), "UTF-8");
            response.sendRedirect("error.jsp?message=" + encodedMessage);
            return;
        }

        double totalAmount = 0.0;

        // Fetch basket items and calculate total cost
        try (Connection conn = DatabaseUtil.getConnection()) {
            conn.setAutoCommit(false);

            String selectBasket = "SELECT product_id, quantity FROM basket WHERE user_id = ?";
            String selectProduct = "SELECT price FROM products WHERE id = ?";
            String updateStock = "UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?";
            String deleteBasket = "DELETE FROM basket WHERE user_id = ?";
            String insertOrder = "INSERT INTO orders (user_id, product_id, quantity) VALUES (?, ?, ?)";

            try (PreparedStatement stmtSelect = conn.prepareStatement(selectBasket);
                 PreparedStatement stmtProduct = conn.prepareStatement(selectProduct);
                 PreparedStatement stmtUpdate = conn.prepareStatement(updateStock);
                 PreparedStatement stmtDelete = conn.prepareStatement(deleteBasket);
                 PreparedStatement stmtInsertOrder = conn.prepareStatement(insertOrder)) {

                stmtSelect.setInt(1, userId);
                try (ResultSet rs = stmtSelect.executeQuery()) {

                    while (rs.next()) {
                        int productId = rs.getInt("product_id");
                        int quantity = rs.getInt("quantity");

                        // Get product price
                        stmtProduct.setInt(1, productId);
                        try (ResultSet productRs = stmtProduct.executeQuery()) {
                            if (productRs.next()) {
                                double price = productRs.getDouble("price");
                                totalAmount += price * quantity;
                            }
                        }

                        // Check if enough stock is available
                        stmtUpdate.setInt(1, quantity);
                        stmtUpdate.setInt(2, productId);
                        stmtUpdate.setInt(3, quantity);
                        if (stmtUpdate.executeUpdate() > 0) {
                            // Insert the order into the orders table
                            stmtInsertOrder.setInt(1, userId);
                            stmtInsertOrder.setInt(2, productId);
                            stmtInsertOrder.setInt(3, quantity);
                            stmtInsertOrder.executeUpdate();
                        } else {
                            throw new SQLException("Not enough stock for product ID: " + productId);
                        }
                    }

                    // Check if the user has enough balance to complete the purchase
                    if (balance < totalAmount) {
                        String encodedMessage = URLEncoder.encode("Insufficient balance for this purchase.", "UTF-8");
                        response.sendRedirect("error.jsp?message=" + encodedMessage);
                        return;
                    }

                    // Deduct the total amount from the user's balance
                    String updateBalance = "UPDATE users SET balance = balance - ? WHERE id = ?";
                    try (PreparedStatement stmtUpdateBalance = conn.prepareStatement(updateBalance)) {
                        stmtUpdateBalance.setDouble(1, totalAmount);
                        stmtUpdateBalance.setInt(2, userId);
                        stmtUpdateBalance.executeUpdate();
                    }

                    // Delete items from the basket
                    stmtDelete.setInt(1, userId);
                    stmtDelete.executeUpdate();

                    // Commit the transaction
                    conn.commit();
                } catch (SQLException e) {
                    conn.rollback();
                    String encodedMessage = URLEncoder.encode("SQL Error: " + e.getMessage(), "UTF-8");
                    response.sendRedirect("error.jsp?message=" + encodedMessage);
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
                String encodedMessage = URLEncoder.encode("Database connection error: " + e.getMessage(), "UTF-8");
                response.sendRedirect("error.jsp?message=" + encodedMessage);
                return;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            String encodedMessage = URLEncoder.encode("Database connection error", "UTF-8");
            response.sendRedirect("error.jsp?message=" + encodedMessage);
            return;
        }

        response.sendRedirect("shop.jsp"); // Redirect back to the shop page after checkout
    }
}
