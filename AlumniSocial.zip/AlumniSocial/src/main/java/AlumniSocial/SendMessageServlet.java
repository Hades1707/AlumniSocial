package AlumniSocial;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class SendMessageServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");

        // Redirect to login if user is not authenticated
        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        int receiverId;
        try {
            receiverId = Integer.parseInt(request.getParameter("receiverId"));
        } catch (NumberFormatException e) {
            response.sendRedirect("connections.jsp?error=invalidReceiver");
            return;
        }

        String message = request.getParameter("message");
        if (message == null || message.trim().isEmpty()) {
            response.sendRedirect("connections.jsp?error=emptyMessage");
            return;
        }

        try (Connection conn = DatabaseUtil.getConnection()) {
            String sql = "INSERT INTO messages (sender_id, receiver_id, message, sent_time) " +
                         "VALUES (?, ?, ?, datetime('now'))";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, userId);
                stmt.setInt(2, receiverId);
                stmt.setString(3, message);
                int rowsAffected = stmt.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Message sent successfully from user " + userId + " to user " + receiverId);
                } else {
                    System.out.println("Failed to send message from user " + userId + " to user " + receiverId);
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("connections.jsp?error=databaseError");
            return;
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("connections.jsp?error=serverError");
            return;
        }

        response.sendRedirect("connections.jsp");
    }
}
