package AlumniSocial;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class DeleteUserServlet extends HttpServlet {

    private static final String ADMIN_ROLE = "admin";

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        Integer userId = (Integer) session.getAttribute("userId");
        String role = (String) session.getAttribute("role");

        // Check if the user is logged in and has admin privileges
        if (userId == null || role == null || !ADMIN_ROLE.equals(role)) {
            response.sendRedirect("login.jsp");
            return;
        }

        // Parse and validate targetUserId
        Integer targetUserId;
        try {
            targetUserId = Integer.parseInt(request.getParameter("targetUserId"));
        } catch (NumberFormatException e) {
            response.sendRedirect("error.jsp?message=Invalid user ID");
            return;
        }

        // Prevent self-deletion
        if (targetUserId.equals(userId)) {
            response.sendRedirect("error.jsp?message=You cannot delete your own account");
            return;
        }

        // Delete the user from the database
        try (Connection conn = DatabaseUtil.getConnection()) {
            String sql = "DELETE FROM users WHERE id = ?";
            try (PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setInt(1, targetUserId);
                int rowsDeleted = stmt.executeUpdate();

                if (rowsDeleted > 0) {
                    // Log the action
                    System.out.println("Admin User ID: " + userId + " deleted User ID: " + targetUserId);

                    response.sendRedirect("admin.jsp");
                } else {
                    response.sendRedirect("error.jsp?message=User deletion failed");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp?message=Unable to delete user. Please try again later.");
        }
    }
}
